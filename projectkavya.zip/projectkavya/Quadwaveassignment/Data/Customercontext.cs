﻿using Quadwaveassignment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Quadwaveassignment.Data
{
    public class Customercontext : DbContext
    {
        public Customercontext (DbContextOptions<Customercontext> opt) : base(opt)
        {

        }

        public DbSet<Customer> Customers { set; get; }
        public DbSet<CustomerAddress> CustomerAddresses { set; get; }

        internal void SaveChanges(CustomerAddress c)
        {
            throw new NotImplementedException();
        }
    }
}


