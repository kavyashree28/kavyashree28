﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Quadwaveassignment.Models;

namespace Quadwaveassignment.Data
{
     public interface ICustomer
    {

        public Customer GetCustomer(int Id);
        public List<Customer> GetCustomers();
        public List<CustomerAddress> GetAddress();
        

        public Customer CreateCustomer(Customer c);
        public CustomerAddress CreateAddress(CustomerAddress c);
        public void UpdateCustomer(Customer c);

        public void DeleteCustomer(Customer c);
      
        
        void UpdateCustomerAddress(CustomerAddress c);
        void DeleteCustomerAddress(CustomerAddress c);
        public CustomerAddress GetAddress(int Id);
    }
}
