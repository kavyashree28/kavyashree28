﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Quadwaveassignment.Models;


namespace Quadwaveassignment.Data
{
    public class CustomerInfo : ICustomer

    {
        private readonly Customercontext _context;
        public CustomerInfo(Customercontext context)
        {
            _context = context;
        }

        public CustomerAddress CreateAddress(CustomerAddress c)
        {
            _context.CustomerAddresses.Add(c);
            _context.SaveChanges();
            return (c);
        }

        public Customer CreateCustomer(Customer c)
        {
            _context.Customers.Add(c);
            _context.SaveChanges();
            return c;
        }

        public void DeleteCustomer(Customer c)
        {
            _context.Remove(c);

            _context.SaveChanges();
        }

        public void DeleteCustomerAddress(CustomerAddress c)
        {
            _context.Remove(c);
        }

        public List<CustomerAddress> GetAddress()
        {
            var Add = _context.CustomerAddresses.ToList();
            return Add;
        }

        public CustomerAddress GetAddress(int Id)
        {
            var custAdd = _context.CustomerAddresses.SingleOrDefault(m => m.CustomerId == Id);
            return custAdd;
        }

        public Customer GetCustomer(int Id)
        {
            var cust = _context.Customers.SingleOrDefault(m => m.CustomerId == Id);
            return cust;
        }

        public List<Customer> GetCustomers()
        {
            var custm = _context.Customers.ToList();
            return custm;
        }

        public void UpdateCustomer(Customer c)
        {
            _context.SaveChanges();
        }

        public void UpdateCustomerAddress(CustomerAddress c)
        {
            _context.SaveChanges(c);
        }
        
         
       

        




       
        
    }
}

        
    
      

