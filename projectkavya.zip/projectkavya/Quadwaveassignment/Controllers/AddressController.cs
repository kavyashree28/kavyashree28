﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Quadwaveassignment.Data;
using Quadwaveassignment.Dtos;
using Quadwaveassignment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Quadwaveassignment.Controllers
{
    [ApiController]
    [Route("api/[Controller")]
    public class AddressController : Controller
    {
        private readonly ICustomer _info;
        private readonly IMapper _mapper;

        public object CustomerAddressReadDto { get;  set; }

        public  AddressController (ICustomer info, IMapper mapper)
        {
            _info = info;
            _mapper = mapper;
        }
            [HttpGet]
            public ActionResult<IEnumerable<AddressReadDto>> GetAddress()
        {
            var Add = _info.GetAddress();
            return Ok(_mapper.Map < IEnumerable < AddressReadDto >> (Add));
        }
        [HttpPost]
        public ActionResult<AddressCreateDto> CreateAddresss(AddressCreateDto customerAddressDto)
        {
            if (customerAddressDto != null)
            {
                var newAdd = _mapper.Map<CustomerAddress>(customerAddressDto);
                _info.CreateAddress(newAdd);
                return Ok(customerAddressDto);
            }
            else
            {
                return NotFound();
            }
        }
        }
    }

