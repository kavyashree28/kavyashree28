﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Quadwaveassignment.Dtos
{
    public class AddressUpdateDto
    {
        public string Country { set; get; }
            public string City { set; get; }
            public string Streetaddress { set; get; }
            public string Phone { set; get; }
    }
}
