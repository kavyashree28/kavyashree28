﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Quadwaveassignment.Dtos
{
    public class AddressReadDto
    {
        public int CustomerId { set; get; }
            public string Country { set; get; }
            public string City { set; get; }
            public string Streetaddress { set; get; }
            public string Phone { set; get; }
    }
}
